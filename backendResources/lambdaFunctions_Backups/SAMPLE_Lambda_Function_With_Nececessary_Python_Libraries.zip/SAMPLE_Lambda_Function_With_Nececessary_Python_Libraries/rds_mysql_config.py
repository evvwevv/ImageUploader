#config file containing credentials for rds mysql instance
# actual username and password was not included for security purposes
db_username = "HIDDEN"
db_password = "HIDDEN"
db_name = "imageuploader_webapp_db"